# Import all models to ensure Alembic can discover them
from app.models.profile import Profile, PatientProfile, ConsentRecord
from app.models.audit import AuditLog
from app.models.breast_awareness import BreastAwarenessSession, BreastSymptomEntry, BreastLocationEntry, BreastAnswer, BreastTriageResult, BreastSummaryReport
from app.models.research import ResearchDataset, DatasetVersion, DatasetValidationRun
