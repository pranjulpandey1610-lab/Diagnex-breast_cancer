# Approved research data workspace

Only institutionally approved, de-identified research datasets may enter this workspace.
Patient uploads, conversations, breast-awareness sessions, and scan records are prohibited inputs.
This phase validates and documents datasets; it does not train or evaluate a model.
